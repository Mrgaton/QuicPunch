import {launchBrowser,startPreviewServer,closeBrowserFixture} from './snapshot/QuicPunchTests/Fixtures/BrowserFixture.mjs';
import {writeFile} from 'node:fs/promises';import {resolve} from 'node:path';
const server=startPreviewServer(['--empty']),dir=resolve('.artifacts/design-audit-2026-11-06'),results=[];let browser;
const log=(name,data)=>{results.push({name,...data});console.log(name,JSON.stringify(data));};
try{const url=await server.ready;browser=await launchBrowser();const p=await browser.newPage({viewport:{width:390,height:844}});
 const shot=async name=>p.screenshot({path:resolve(dir,'edge-'+name+'.png'),fullPage:true,animations:'disabled'});
 await p.goto(url);await p.waitForFunction(()=>QP.state.status);await shot('home-empty');
 log('empty-home',await p.evaluate(()=>({buttons:[...document.querySelectorAll('#view-dashboard button')].filter(e=>e.checkVisibility()).map(e=>({label:e.innerText,y:e.getBoundingClientRect().top})),nav:[...document.querySelectorAll('.nav-link')].filter(e=>e.checkVisibility()).map(e=>e.innerText)})));
 for(const route of ['chat.html','call.html','vpn.html','speedtest.html','updates-help.html']){await p.goto(url+route);await p.waitForTimeout(250);await shot(route.replace('.html',''));log('empty-'+route,await p.evaluate(()=>({width:innerWidth,scrollWidth:document.documentElement.scrollWidth,scrollHeight:document.documentElement.scrollHeight})));}
 await p.setViewportSize({width:320,height:568});await p.goto(url+'updates-help.html');await shot('help-320');log('help-320',await p.evaluate(()=>({width:innerWidth,scrollWidth:document.documentElement.scrollWidth,pre:[...document.querySelectorAll('pre')].map(e=>({width:e.clientWidth,scrollWidth:e.scrollWidth,overflow:getComputedStyle(e).overflow}))})));
 await p.setViewportSize({width:390,height:844});let broken=true,calls=0;
 await p.route('**/api/profile',r=>{calls++;return r.fulfill(broken?{status:503,json:{success:false,error:'El servicio de perfil no responde'}}:{json:{customName:'Ana',deviceName:'Portátil',displayName:'Ana'}});});
 await p.goto(url+'settings.html');await p.locator('#profileSaveStatus').filter({hasText:'No se pudo'}).waitFor();broken=false;
 await p.locator('#settingsCategory').selectOption('notifications');await p.locator('#settingsCategory').selectOption('profile');
 log('profile-retry',{calls,disabled:await p.locator('#profileDisplayName').isDisabled(),message:await p.locator('#profileSaveStatus').innerText()});await shot('profile-error');
 await p.locator('#settingsCategory').selectOption('connection');
 await p.evaluate(()=>{const s=structuredClone(QP.state.status);s.wan.lastError='Fallo de conexión de ejemplo';s.logs=[{message:'Fallo de conexión de ejemplo',level:'error'}];QP.emit('status_updated',s);});
 await p.locator('#wanMeta').click();log('service-error-navigation',{section:await p.locator('#settingsCategory').inputValue(),logsVisible:await p.locator('#logs').isVisible()});await shot('service-error-link');
 log('mobile-tools-location',await p.locator('.mobile-tools').evaluate(e=>({panel:e.closest('[data-settings-panel]')?.id,top:e.getBoundingClientRect().top,text:e.innerText})));
 await p.goto(url+'chat.html');await p.evaluate(()=>QP.emit('ws_status',{connected:false}));await shot('chat-disconnected');
 await p.setViewportSize({width:1440,height:900});await p.goto(url+'settings.html');await p.locator('#profilePhotoFile').setInputFiles(resolve(dir,'390-home.png'));
 await p.waitForTimeout(1200);log('avatar-load',{message:await p.locator('#profilePhotoStatus').innerText(),open:await p.locator('#avatarCropModal:not(.hidden)').count()});
 if(await p.locator('#avatarCropModal:not(.hidden)').count()){await p.setViewportSize({width:320,height:568});await shot('avatar-crop-320');
 log('avatar-crop',await p.evaluate(()=>({scrollWidth:document.documentElement.scrollWidth,width:innerWidth,canvas:document.getElementById('avatarCropCanvas').getBoundingClientRect().toJSON(),confirm:document.querySelector('#avatarCropModal .modal-foot')?.getBoundingClientRect().toJSON()})));await p.keyboard.press('Escape');}
}finally{await writeFile(resolve(dir,'edge-results.json'),JSON.stringify(results,null,2));await closeBrowserFixture(browser,server);}
