import {launchBrowser,startPreviewServer,closeBrowserFixture} from './snapshot/QuicPunchTests/Fixtures/BrowserFixture.mjs';
import {readFile,writeFile} from 'node:fs/promises';
import {resolve,extname} from 'node:path';
import {createServer} from 'node:http';
import {generateKeyPairSync,sign} from 'node:crypto';
const dir=resolve('.artifacts/design-audit-2026-11-06'),observations=[];
const server=startPreviewServer();let browser,downloadServer;
const log=(name,data)=>{observations.push({name,...data});console.log(name,JSON.stringify(data));};
try{
 const url=await server.ready;browser=await launchBrowser();
 const page=await browser.newPage({viewport:{width:1440,height:900},locale:'es-ES'});
 async function shot(name,p=page){await p.screenshot({path:resolve(dir,'deep-'+name+'.png'),fullPage:true,animations:'disabled'});}
 async function axeCheck(name,p=page){await p.addScriptTag({path:resolve(dir,'package/axe.min.js')});const r=await p.evaluate(async()=>await axe.run(document));log(name,{violations:r.violations.map(v=>({id:v.id,nodes:v.nodes.map(n=>({target:n.target,summary:n.failureSummary}))}))});}
 await page.goto(url+'settings.html?section=contacts');await page.waitForFunction(()=>QP.state.status);await page.locator('[data-subtab="tab-saved-peers"]').click();
 await page.locator('#savedPeersBody .peer-permissions summary').first().click();
 await page.locator('#savedPeersBody .peer-permissions input:not([disabled])').first().focus();
 await page.evaluate(()=>{window.beforePermission=document.activeElement;QP.emit('status_updated',structuredClone(QP.state.status));});
 log('saved-permissions-refresh',{open:await page.locator('#savedPeersBody .peer-permissions[open]').count(),focus:await page.evaluate(()=>({id:document.activeElement.id,tag:document.activeElement.tagName,previousConnected:beforePermission.isConnected}))});
 await page.locator('#savedPeersBody').getByRole('button',{name:'Editar',exact:true}).first().click();await shot('edit-contact');await axeCheck('edit-contact-a11y');
 await page.keyboard.press('Escape');
 page.once('dialog',async d=>{log('delete-contact-confirm',{message:d.message()});await d.dismiss();});
 await page.locator('#savedPeersBody').getByRole('button',{name:'Eliminar',exact:true}).first().click();
 await page.route('**/api/peer/profile',r=>{log('admin-request',{body:r.request().postDataJSON()});return r.fulfill({json:{success:true}});});
 await page.locator('#savedPeersBody select').first().selectOption('administrator');await shot('admin-profile');
 const voiceSource=await readFile(resolve(dir,'snapshot/QuicNet.Shared/wwwroot/voice.js'),'utf8');
 await page.route('**/voice.js',r=>r.fulfill({contentType:'application/javascript',body:voiceSource.replace(/\}\)\(\);\s*$/,`window.auditVoice=()=>{const base=QP.state.status;voiceStatus={...base,activeVoiceCalls:[{peerId:base.peers[0].id,peerName:base.peers[0].name}]};voiceState={isMuted:false,isDeafened:false,masterVolume:1,captureRunning:false,playbackRunning:false,backendName:'Fixture',activeCalls:voiceStatus.activeVoiceCalls.map(c=>({...c,volume:1,muted:false,screenShareAllowed:true}))};renderVoice();};})();`)}));
 for(const vp of [{width:844,height:390},{width:667,height:375},{width:320,height:568}]){
  await page.setViewportSize(vp);await page.goto(url+'call.html');await page.waitForFunction(()=>QP.state.status);await page.evaluate(()=>auditVoice());
  log('active-call-'+vp.width,await page.locator('#voiceLeaveBtn').evaluate(e=>{const b=e.getBoundingClientRect(),d=e.closest('.voice-dock');return {rect:b.toJSON(),viewport:innerHeight,disabled:e.disabled,elementAtCenter:document.elementFromPoint(b.x+b.width/2,b.y+b.height/2)?.id,dockClient:d.clientHeight,dockScroll:d.scrollHeight,dockOverflow:getComputedStyle(d).overflow,bodyOverflow:getComputedStyle(document.body).overflow};}));await shot('active-call-'+vp.width);
 }
 await page.setViewportSize({width:390,height:844});await page.goto(url+'call.html');await page.locator('#voiceScreenSettingsBtn').click();await page.locator('#mediaVideoTab').click();await shot('video-settings-mobile');await axeCheck('video-settings-a11y');
 await page.locator('#mediaVideoPanel').evaluate(e=>e.closest('.modal-body').scrollTop=99999);await shot('video-settings-bottom');
 await page.keyboard.press('Escape');
 await page.setViewportSize({width:1440,height:900});
 const share={id:'example-share',name:'Documentos compartidos',root:'C:\\Demo',writable:true,allowDelete:true};
 await page.route('**/api/virtual-disk/operation',r=>{const q=r.request().postDataJSON().request;return r.fulfill({json:q.operation==='shares'?{success:true,shares:[share],canExplore:true}:q.operation==='list'?{success:true,entries:[{name:'Una carpeta',path:'Una carpeta',directory:true},{name:'ejemplo.txt',path:'ejemplo.txt',directory:false}],more:false}:{success:true}});});
 await page.goto(url+'virtual-disk.html');await page.locator('.disk-share .disk-name').first().click();await page.locator('#diskPath').fill('carpeta/que/estoy/escribiendo');
 log('disk-path-before-poll',{value:await page.locator('#diskPath').inputValue()});await page.waitForTimeout(5300);
 log('disk-path-after-poll',{value:await page.locator('#diskPath').inputValue()});
 log('upload-keyboard',await page.locator('#diskUploadLabel').evaluate(e=>({html:e.outerHTML,tabIndex:e.tabIndex,inputDisplay:getComputedStyle(e.querySelector('input')).display})));
 await shot('disk-populated');await axeCheck('disk-populated-a11y');
 const wp=await browser.newPage({viewport:{width:390,height:844},locale:'es-ES'});
 let watchState={local:{name:'Mi portátil',token:'INVITACION-DE-EJEMPLO'},peers:[],room:null};
 await wp.route('**/watch/api/status',r=>r.fulfill({json:watchState}));await wp.routeWebSocket(/\/watch\/ws/,s=>{});
 await wp.goto(url+'watch/');await wp.locator('#connectionText').filter({hasText:/listo|compartir/i}).waitFor();await shot('watch-empty-mobile',wp);await axeCheck('watch-empty-a11y',wp);
 log('watch-first-action',await wp.locator('#createRoom').evaluate(e=>({top:e.getBoundingClientRect().top,viewport:innerHeight,label:e.innerText})));
 watchState={...watchState,peers:[{peerId:'demo',name:'Ana',connected:true,inRoom:true,role:'Viewer'}],room:{roomId:'demo-room',name:'Reunion'.repeat(8),isOwner:true,myRole:'Owner',media:null}};
 await wp.reload();await wp.locator('#roomTitle').filter({hasText:'Reunion'}).waitFor();await shot('watch-long-name',wp);
 log('watch-long-name',await wp.evaluate(()=>({width:innerWidth,scrollWidth:document.documentElement.scrollWidth,titleWidth:document.getElementById('roomTitle').getBoundingClientRect().width})));
 await axeCheck('watch-room-a11y',wp);
 watchState={...watchState,room:{...watchState.room,name:'Noche de cine'}};await wp.reload();await wp.locator('#leaveRoom').waitFor();
 await wp.route('**/watch/api/permission',r=>r.fulfill({status:403,json:{success:false,error:'No se pudo guardar el permiso.'}}));
 await wp.locator('.role-select').selectOption('Controller');await wp.locator('#toast').filter({hasText:'No se pudo guardar'}).waitFor();
 log('watch-role-rejected',{value:await wp.locator('.role-select').inputValue()});await wp.waitForTimeout(4300);
 log('watch-role-after-refresh',{value:await wp.locator('.role-select').inputValue(),toastVisible:await wp.locator('#toast').isVisible()});await shot('watch-role-error-lost',wp);
 // A temporary test identity exists only in process memory; no release keys are accessed or saved.
 const {privateKey,publicKey}=generateKeyPairSync('rsa',{modulusLength:2048});
 let fail=true;downloadServer=createServer(async(req,res)=>{const path=new URL(req.url,'http://localhost').pathname.slice(1);res.setHeader('Content-Type',({'.css':'text/css','.js':'text/javascript','.html':'text/html'})[extname(path||'index.html')]||'text/plain');
  if(path==='release-public.pem')return res.end(publicKey.export({type:'spki',format:'pem'}));
  if(path.startsWith('latest')){if(fail){res.writeHead(503);return res.end('Unavailable');}const channel=path.includes('beta')?'beta':'stable';const payload=Buffer.from(JSON.stringify({schema:1,channel,version:'1.0.0',build:1,artifacts:{'win-x64':{compressed:{size:123},size:456}}}));res.setHeader('Content-Type','application/json');return res.end(JSON.stringify({payload:payload.toString('base64'),signature:sign('sha256',payload,privateKey).toString('base64')}));}
  try{let data=await readFile(resolve(dir,'snapshot/scripts/download-page',path||'index.html'));if(!path||path.endsWith('.html'))data=data.toString().replaceAll('__ASSET_PREFIX__','.');res.end(data);}catch{res.writeHead(404);res.end('Not found');}
 });await new Promise(r=>downloadServer.listen(0,'127.0.0.1',r));
 const dp=await browser.newPage({viewport:{width:390,height:844}});await dp.goto('http://127.0.0.1:'+downloadServer.address().port+'/');await dp.locator('#status.error').waitFor();await shot('download-error',dp);await axeCheck('download-error-a11y',dp);
 log('download-error',{release:await dp.locator('#release').innerText(),status:await dp.locator('#status').innerText(),retryVisible:await dp.locator('#retry').isVisible()});
 fail=false;await dp.reload();await dp.locator('#download:not([disabled])').waitFor();await shot('download-ready',dp);await axeCheck('download-ready-a11y',dp);
}finally{await writeFile(resolve(dir,'deep-results.json'),JSON.stringify(observations,null,2));await closeBrowserFixture(browser,server);if(downloadServer)await new Promise(r=>downloadServer.close(r));}
