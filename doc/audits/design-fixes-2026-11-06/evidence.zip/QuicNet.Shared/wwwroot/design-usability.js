document.addEventListener('DOMContentLoaded',()=>{
  const dialog=document.getElementById('mobileToolsDialog');
  document.getElementById('openMobileTools').addEventListener('click',()=>dialog.showModal());
  document.querySelectorAll('[data-open-tools]').forEach(button=>button.addEventListener('click',()=>dialog.showModal()));
  document.getElementById('closeMobileTools').addEventListener('click',()=>dialog.close());
  dialog.querySelectorAll('a').forEach(link=>link.addEventListener('click',()=>dialog.close()));
});
