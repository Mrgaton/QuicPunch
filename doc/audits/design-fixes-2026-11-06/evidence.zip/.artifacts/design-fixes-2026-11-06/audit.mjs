import {launchBrowser,startPreviewServer,closeBrowserFixture} from '../../QuicPunchTests/Fixtures/BrowserFixture.mjs';
import {writeFile,mkdir} from 'node:fs/promises';
import {resolve} from 'node:path';
const dir=resolve('.artifacts/design-fixes-2026-11-06');
const server=startPreviewServer(); let browser; const results=[];
const peer='00000000-0000-0000-0000-000000000001';
try {
 const url=await server.ready; browser=await launchBrowser();
 const page=await browser.newPage({viewport:{width:1440,height:900},locale:'es-ES'});
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.route('**/api/profile',r=>r.fulfill({json:{customName:'Ana',displayName:'Ana',deviceName:'Mi portátil'}}));
 await page.route('**/api/app/preferences',r=>r.fulfill({json:{success:true,settings:{startWithSystem:true,runInBackground:true,notifications:{enabled:true,desktop:true,inApp:true,sound:true,preview:true,whileFocused:true,doNotDisturb:false,quietHours:false,quietStart:1320,quietEnd:480,volume:60,tone:'soft',features:{},contacts:{}}},startupSupported:true,platformHelp:'Al cerrar la ventana, QuicNet continúa en segundo plano.'}}));
 await page.route('**/api/chat/messages?**',r=>r.fulfill({json:{messages:Array.from({length:14},(_,i)=>({peerId:peer,msgId:'audit-'+i,sender:i%2?'Tú':'Ana',message:i===5?'https://example.com/'+ 'un-enlace-largo-'.repeat(20):i%2?'Sí, lo revisamos esta tarde.':'Te envío los detalles de la reunión. ¿Puedes comprobar que se leen bien?',isMe:!!(i%2),isConfirmed:true,time:'12:00',timestampMs:Date.now()-60000*(14-i)})),nextBefore:null}}));
 async function capture(name,axe=true){
  await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
  await page.screenshot({path:resolve(dir,name+'.png'),fullPage:true,animations:'disabled'});
  const geometry=await page.evaluate(()=>{
   const visible=e=>e.checkVisibility()&&e.getBoundingClientRect().width>0&&e.getBoundingClientRect().height>0;
   const label=e=>e.getAttribute('aria-label')||e.labels?.[0]?.innerText||e.innerText?.trim().slice(0,90)||e.getAttribute('title')||'';
   const controls=[...document.querySelectorAll('button,input,select,textarea,summary,a[href]')].filter(visible).map(e=>{let r=e.getBoundingClientRect();return {id:e.id,tag:e.tagName,label:label(e),width:r.width,height:r.height,x:r.x,y:r.y,font:getComputedStyle(e).fontSize,disabled:e.disabled||false};});
   const clipped=[...document.querySelectorAll('body *')].filter(e=>visible(e)&&e.children.length===0&&e.textContent.trim()&&e.clientWidth>0&&e.scrollWidth>e.clientWidth+3).map(e=>({id:e.id,cls:e.className,text:e.textContent.slice(0,100),width:e.clientWidth,scrollWidth:e.scrollWidth,overflow:getComputedStyle(e).overflow}));
   return {width:innerWidth,height:innerHeight,scrollWidth:document.documentElement.scrollWidth,scrollHeight:document.documentElement.scrollHeight,controls,clipped};
  });
  let violations=[];
  if(axe){await page.addScriptTag({path:resolve('.artifacts/design-audit-2026-11-06/package/axe.min.js')});const a=await page.evaluate(async()=>await axe.run(document,{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21aa','wcag22aa','best-practice']}}));violations=a.violations.map(v=>({id:v.id,impact:v.impact,description:v.description,nodes:v.nodes.map(n=>({target:n.target,html:n.html,summary:n.failureSummary}))}));}
  results.push({name,...geometry,axeChecked:axe,violations});
  await writeFile(resolve(dir,'results.json'),JSON.stringify({errors,results},null,2));
  console.log(name+' '+JSON.stringify({overflow:geometry.scrollWidth>geometry.width,violations:violations.map(v=>v.id+':'+v.nodes.length)}));
 }
 for(const viewport of [{width:1440,height:900},{width:768,height:1024},{width:390,height:844},{width:320,height:568},{width:844,height:390}]){
  await page.setViewportSize(viewport);
  for(const route of ['','chat.html','call.html','vpn.html','speedtest.html','watch.html','virtual-disk.html']){
   await page.goto(url+route);await page.waitForFunction(()=>window.QP?.state.status);await page.waitForTimeout(300);
   await capture(viewport.width+'-'+(route.replace('.html','')||'home'),viewport.width===1440||viewport.width===390);
  }
  await page.goto(url+'chat.html?peer='+peer);await page.locator('#messageInput:not([disabled])').waitFor();await capture(viewport.width+'-chat-conversation',viewport.width===390);
 }
 for(const width of [1440,390]){
  await page.setViewportSize({width,height:900});
  await page.goto(url+'settings.html');await page.waitForFunction(()=>window.QP?.state.status);
  const sections=await page.locator('[data-settings-section]').evaluateAll(es=>es.map(e=>e.dataset.settingsSection));
  for(const section of sections){
   if(width>1000)await page.locator('#settings-tab-'+section).click();else await page.locator('#settingsCategory').selectOption(section);
   await capture(width+'-settings-'+section);
   if(section==='contacts'||section==='diagnostics')for(const tab of await page.locator('[data-group="'+(section==='contacts'?'peerdir':'diagtabs')+'"]').all()){
    await tab.click();await capture(width+'-'+await tab.getAttribute('data-subtab'));
   }
  }
  await page.goto(url);await page.waitForFunction(()=>window.QP?.state.status);await page.locator('#openShareInvitation').click();await capture(width+'-invitation');await page.keyboard.press('Escape');
  await page.goto(url+'call.html');await page.locator('#voiceScreenSettingsBtn').click();await page.locator('#mediaVideoTab').click();await capture(width+'-media-video');
  await page.locator('#mediaAudioTab').click();await capture(width+'-media-audio');

 }
 console.log('DONE '+results.length);
} finally{await closeBrowserFixture(browser,server);}
